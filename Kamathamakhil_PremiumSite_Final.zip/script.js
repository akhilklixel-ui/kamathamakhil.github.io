// Splash screen fade-out (only 0.5s)
window.addEventListener('load', () => {
  const splash = document.querySelector('.splash-screen');
  if (splash) {
    splash.classList.add('fade-out');
    setTimeout(() => {
      splash.style.display = 'none';
    }, 500); // 0.5 seconds
  }
});